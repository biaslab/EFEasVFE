"""
    MPSAgent.jl

    Phase 2 & 3: The MPS-based Active Inference Agent

    This module implements:
    - MPSAgent struct (Phase 2): holds beliefs as MPS instead of dense vectors
    - Operation A: Transition via MPO application + SVD truncation
    - Operation C: Message passing / variational update via DMRG-like sweeps
    - The full iterative VFE minimization loop (Algorithm 1 from the paper)
"""
module MPSAgent

using LinearAlgebra
include("MPSEntropy.jl")
using .MPSEntropy

export MPSBeliefAgent,
       initialize_product_state,
       apply_transition!,
       variational_sweep!,
       infer_policy!,
       MPOTensor, MPO,
       transition_to_mpo,
       normalize_mps!

# ══════════════════════════════════════════════════════════════════════════════
# Phase 2: Data Structures
# ══════════════════════════════════════════════════════════════════════════════

"""
    MPOTensor

A single tensor in a Matrix Product Operator.
Shape: (χ_L, d_out, d_in, χ_R)

For transition matrices T(u): d_out = d_in = number of states
The MPO applies to an MPS as: |ψ'⟩ = T |ψ⟩
"""
struct MPOTensor{T<:Number}
    data::Array{T, 4}  # (χ_L, d_out, d_in, χ_R)
end

struct MPO{T<:Number}
    tensors::Vector{MPOTensor{T}}
    bond_dim::Int
end

"""
    MPSBeliefAgent

The refactored agent that stores its belief state as an MPS.

Fields:
- belief: MPS representing q(x₀, x₁, ..., x_T) — the posterior over state trajectories
- transitions: Dict mapping action u → MPO representing p(xₜ|xₜ₋₁, u)
- observations: MPS or dense matrix for p(yₜ|xₜ)
- preference: Vector representing p̂(xₜ) — the goal prior
- bond_dim: Maximum bond dimension χ
- n_states: Physical dimension d (number of states per timestep)
- horizon: Planning horizon T
- n_actions: Number of available actions
"""
mutable struct MPSBeliefAgent{T<:Number}
    belief::MPS{T}
    transitions::Dict{Int, MPO{T}}           # action → MPO
    observation_model::Matrix{T}             # p(y|x), dense for now (d_obs × d_state)
    preference::Vector{T}                    # p̂(x), goal prior
    bond_dim::Int                            # χ_max
    n_states::Int                            # d
    horizon::Int                             # T
    n_actions::Int
    n_iterations::Int                        # τ_max for VI loop
end

# ══════════════════════════════════════════════════════════════════════════════
# Phase 2: Initialization
# ══════════════════════════════════════════════════════════════════════════════

"""
    initialize_product_state(n_states, horizon, bond_dim; start_state=1) → MPS

Create an MPS as a product state (zero entanglement) representing
the initial belief q₀(x₀,...,x_T).

A product state means: q(x₀,...,x_T) = q(x₀) · q(x₁) · ... · q(x_T)
where each marginal is either:
- A delta at `start_state` for t=0
- Uniform over all states for t>0 (maximum ignorance)

This is the simplest possible initialization and corresponds to
the "uninformative distribution" in Algorithm 1, line 3.
"""
function initialize_product_state(
    n_states::Int,
    horizon::Int,
    bond_dim::Int;
    start_state::Int = 1,
    T_type::Type = Float64
)
    tensors = MPSTensor{T_type}[]

    for t in 1:horizon
        χL = 1  # Product state: all bond dimensions = 1
        χR = 1

        A = zeros(T_type, χL, n_states, χR)

        if t == 1
            # Delta distribution at start state
            A[1, start_state, 1] = 1.0
        else
            # Uniform distribution: √(1/d) for each state
            # (amplitude, not probability — q(x) = ψ(x)²)
            for x in 1:n_states
                A[1, x, 1] = sqrt(1.0 / n_states)
            end
        end

        push!(tensors, MPSTensor(A))
    end

    return MPS(tensors, bond_dim)
end

"""
    normalize_mps!(ψ::MPS)

Normalize the MPS so that ∑_x |ψ(x)|² = 1.
Done via a sweep from left to right using QR decomposition,
then rescaling the last tensor.
"""
function normalize_mps!(ψ::MPS{T}) where T
    L = nsites(ψ)

    # Left-to-right QR sweep to put in left-canonical form
    for k in 1:L-1
        A = ψ.tensors[k].data  # (χL, d, χR)
        χL, d, χR = size(A)

        # Reshape to matrix: (χL·d, χR)
        mat = reshape(A, χL * d, χR)
        F = qr(mat)
        Q = Matrix(F.Q)  # (χL·d, min(χL·d, χR))
        R = F.R           # (min(χL·d, χR), χR)

        new_χR = size(Q, 2)

        # Update current tensor
        ψ.tensors[k] = MPSTensor(reshape(Q, χL, d, new_χR))

        # Absorb R into next tensor
        A_next = ψ.tensors[k+1].data  # (χR, d_next, χR_next)
        χR_old, d_next, χR_next = size(A_next)
        A_next_mat = reshape(A_next, χR_old, d_next * χR_next)
        new_A_next = R * A_next_mat  # (new_χR, d_next * χR_next)
        ψ.tensors[k+1] = MPSTensor(reshape(new_A_next, new_χR, d_next, χR_next))
    end

    # Normalize the last tensor
    A_last = ψ.tensors[L].data
    norm_val = sqrt(sum(abs2, A_last))
    if norm_val > 0
        ψ.tensors[L] = MPSTensor(A_last ./ norm_val)
    end

    return ψ
end

# ══════════════════════════════════════════════════════════════════════════════
# Operation A: Transition as MPO Application
# ══════════════════════════════════════════════════════════════════════════════

"""
    transition_to_mpo(T_matrix::Matrix, site::Int, horizon::Int) → MPO

Convert a dense transition matrix T(u) ∈ ℝ^{d×d} into a Matrix Product Operator.

For a single-site transition (state at time t depends only on state at time t-1),
the MPO has a simple structure:
- Identity at all sites except `site`
- At `site`: the transition matrix T(u)

The MPO bond dimension for this case is 1 (no entanglement in the operator).
For more complex transitions (e.g., depending on multiple past states),
the MPO bond dimension would grow.

T_matrix[x_new, x_old] = p(x_new | x_old, u)
"""
function transition_to_mpo(
    T_matrix::Matrix{T},
    site::Int,
    horizon::Int
) where T
    d = size(T_matrix, 1)
    @assert size(T_matrix, 2) == d "Transition matrix must be square"

    tensors = MPOTensor{T}[]

    for t in 1:horizon
        if t == site
            # The actual transition: W^{x_out, x_in} = T[x_out, x_in]
            # Shape: (1, d, d, 1) — MPO bond dim = 1
            W = zeros(T, 1, d, d, 1)
            for xout in 1:d, xin in 1:d
                W[1, xout, xin, 1] = T_matrix[xout, xin]
            end
            push!(tensors, MPOTensor(W))
        else
            # Identity operator: δ(x_out, x_in)
            W = zeros(T, 1, d, d, 1)
            for x in 1:d
                W[1, x, x, 1] = one(T)
            end
            push!(tensors, MPOTensor(W))
        end
    end

    return MPO(tensors, 1)
end

"""
    apply_transition!(agent::MPSBeliefAgent, action::Int, timestep::Int)

Operation A: Apply the transition MPO for the given action to the belief MPS,
then truncate back to the maximum bond dimension using SVD.

This replaces the dense operation: q_next = T(u) * q_curr

Steps:
1. Contract MPO with MPS to get a new MPS (bond dim may increase)
2. SVD-truncate to maintain bond_dim ≤ χ_max
"""
function apply_transition!(agent::MPSBeliefAgent{T}, action::Int, timestep::Int) where T
    ψ = agent.belief
    W = agent.transitions[action]
    L = nsites(ψ)
    χ_max = agent.bond_dim

    # Step 1: Contract MPO × MPS at each site
    # New MPS tensor at site k:
    #   B^{x_out}[k]_{(α,a),(β,b)} = ∑_{x_in} W^{x_out,x_in}[k]_{a,b} · A^{x_in}[k]_{α,β}
    #
    # where (α,a) is the combined left bond and (β,b) is the combined right bond.
    new_tensors = MPSTensor{T}[]

    for k in 1:L
        A = ψ.tensors[k].data    # (χL_A, d, χR_A)
        Wk = W.tensors[k].data   # (χL_W, d_out, d_in, χR_W)

        χL_A, d_in, χR_A = size(A)
        χL_W, d_out, _, χR_W = size(Wk)

        # Combined bond dimensions
        χL_new = χL_A * χL_W
        χR_new = χR_A * χR_W

        B = zeros(T, χL_new, d_out, χR_new)

        for xout in 1:d_out, xin in 1:d_in
            for αA in 1:χL_A, aW in 1:χL_W, βA in 1:χR_A, bW in 1:χR_W
                row = (αA - 1) * χL_W + aW
                col = (βA - 1) * χR_W + bW
                B[row, xout, col] += Wk[aW, xout, xin, bW] * A[αA, xin, βA]
            end
        end

        push!(new_tensors, MPSTensor(B))
    end

    agent.belief = MPS(new_tensors, χ_max)

    # Step 2: SVD truncation sweep (left-to-right)
    svd_truncate!(agent.belief, χ_max)

    # Step 3: Normalize
    normalize_mps!(agent.belief)
end

"""
    svd_truncate!(ψ::MPS, χ_max::Int)

Truncate the MPS bond dimensions to at most χ_max using SVD.
Performs a left-to-right sweep, decomposing each bond via SVD
and keeping only the χ_max largest singular values.

This is the core compression step that makes the MPS approach tractable.
The truncation error is bounded by the sum of discarded singular values squared.
"""
function svd_truncate!(ψ::MPS{T}, χ_max::Int) where T
    L = nsites(ψ)

    for k in 1:L-1
        A = ψ.tensors[k].data  # (χL, d, χR)
        χL, d, χR = size(A)

        # Reshape to matrix: (χL·d, χR)
        mat = reshape(A, χL * d, χR)

        # SVD
        F = svd(mat)
        U = F.U    # (χL·d, min(χL·d, χR))
        S = F.S    # singular values
        Vt = F.Vt  # (min(χL·d, χR), χR)

        # Truncate to χ_max
        χ_new = min(χ_max, length(S))

        # Keep only the top χ_new singular values
        U_trunc = U[:, 1:χ_new]         # (χL·d, χ_new)
        S_trunc = Diagonal(S[1:χ_new])  # (χ_new, χ_new)
        Vt_trunc = Vt[1:χ_new, :]       # (χ_new, χR)

        # Absorb S into the right: S·Vᵀ → becomes the left part of next tensor
        SV = S_trunc * Vt_trunc  # (χ_new, χR)

        # Update current tensor with U
        ψ.tensors[k] = MPSTensor(reshape(U_trunc, χL, d, χ_new))

        # Absorb SV into next tensor
        A_next = ψ.tensors[k+1].data  # (χR, d_next, χR_next)
        d_next = size(A_next, 2)
        χR_next = size(A_next, 3)
        A_next_mat = reshape(A_next, χR, d_next * χR_next)
        new_A_next = SV * A_next_mat  # (χ_new, d_next * χR_next)
        ψ.tensors[k+1] = MPSTensor(reshape(new_A_next, χ_new, d_next, χR_next))
    end
end

# ══════════════════════════════════════════════════════════════════════════════
# Operation C: Variational Update via DMRG-like Sweeps
# ══════════════════════════════════════════════════════════════════════════════

"""
    build_left_environments(ψ::MPS, ψ_target::MPS) → Vector{Matrix}

Build left environment blocks for the DMRG sweep.
L[k] = contraction of sites 1..k of ⟨ψ_target|ψ⟩

These are used in the local optimization at each site.
"""
function build_left_environments(ψ::MPS{T}, ψ_target::MPS{T}) where T
    L = nsites(ψ)
    envs = Matrix{T}[]

    # L[0] = identity (scalar 1)
    push!(envs, ones(T, 1, 1))

    for k in 1:L-1
        A = ψ.tensors[k].data         # (χL, d, χR)
        B = ψ_target.tensors[k].data   # (χL_t, d, χR_t)
        prev = envs[end]                # (χL_t_prev, χL_prev)

        d = phys_dim(ψ.tensors[k])
        χR_A = bond_dim_right(ψ.tensors[k])
        χR_B = bond_dim_right(ψ_target.tensors[k])

        new_env = zeros(T, χR_B, χR_A)

        for x in 1:d
            Ax = @view A[:, x, :]    # (χL_A, χR_A)
            Bx = @view B[:, x, :]    # (χL_B, χR_B)
            # new_env += Bxᵀ · prev · Ax
            new_env .+= Bx' * prev * Ax
        end

        push!(envs, new_env)
    end

    return envs
end

"""
    build_right_environments(ψ::MPS, ψ_target::MPS) → Vector{Matrix}

Build right environment blocks for the DMRG sweep.
R[k] = contraction of sites k..L of ⟨ψ_target|ψ⟩
"""
function build_right_environments(ψ::MPS{T}, ψ_target::MPS{T}) where T
    L = nsites(ψ)
    envs = Vector{Matrix{T}}(undef, L + 1)

    # R[L+1] = identity (scalar 1)
    envs[L + 1] = ones(T, 1, 1)

    for k in L:-1:2
        A = ψ.tensors[k].data
        B = ψ_target.tensors[k].data
        next = envs[k + 1]

        d = phys_dim(ψ.tensors[k])
        χL_A = bond_dim_left(ψ.tensors[k])
        χL_B = bond_dim_left(ψ_target.tensors[k])

        new_env = zeros(T, χL_B, χL_A)

        for x in 1:d
            Ax = @view A[:, x, :]
            Bx = @view B[:, x, :]
            new_env .+= Bx * next * Ax'
        end

        envs[k] = new_env
    end

    # Fill envs[1] with identity of appropriate size
    envs[1] = ones(T, bond_dim_left(ψ_target.tensors[1]),
                      bond_dim_left(ψ.tensors[1]))

    return envs
end

"""
    variational_sweep!(agent::MPSBeliefAgent; target_mps=nothing)

Operation C: Perform one DMRG-like sweep to optimize the belief MPS.

This implements the message passing update (line 9 of Algorithm 1):
    qτ(y, x, u) ← infer(p(y, x, u))

In the MPS formulation, this corresponds to a 1-site DMRG sweep where
at each site k, we:
1. Build the effective Hamiltonian from left/right environments
2. Incorporate the epistemic and preference priors as local potentials
3. Solve the local eigenvalue problem (or direct optimization)
4. SVD to restore MPS canonical form

The "Hamiltonian" here is the negative log of the augmented generative model:
    H_eff = −log p(y,x,u) − log p̂(x) − log p̃(u) − log p̃(x)

Minimizing ⟨ψ|H_eff|ψ⟩ is equivalent to minimizing the VFE.
"""
function variational_sweep!(agent::MPSBeliefAgent{T}; n_sweeps::Int=2) where T
    ψ = agent.belief
    L = nsites(ψ)
    d = agent.n_states

    for sweep in 1:n_sweeps
        # Left-to-right sweep
        for k in 1:L-1
            _optimize_site!(agent, k, :left)
        end
        # Right-to-left sweep
        for k in L:-1:2
            _optimize_site!(agent, k, :right)
        end
    end

    normalize_mps!(agent.belief)
end

"""
    _optimize_site!(agent, k, direction)

Optimize the MPS tensor at site k.

The local update incorporates:
1. Preference prior p̂(xₖ): multiplicative weight favoring goal states
2. Epistemic state prior p̃(xₖ) ∝ exp(−H[q(y|x)]): favors low observation entropy
3. Epistemic action prior (if k is a control site)
4. Left/right environments from neighboring sites
"""
function _optimize_site!(agent::MPSBeliefAgent{T}, k::Int, direction::Symbol) where T
    ψ = agent.belief
    d = agent.n_states
    A = ψ.tensors[k].data  # (χL, d, χR)
    χL, _, χR = size(A)

    # Compute local potential: combines preference + epistemic priors
    local_potential = ones(T, d)

    # Preference prior: p̂(xₖ)
    if length(agent.preference) == d
        local_potential .*= agent.preference
    end

    # Epistemic state prior: p̃(xₖ) ∝ exp(−H[q(y|xₖ)])
    # Compute observation entropy for each state
    obs_model = agent.observation_model  # (d_obs, d_state)
    if size(obs_model, 2) == d
        for x in 1:d
            p_y_given_x = obs_model[:, x]
            p_y_given_x = p_y_given_x ./ max(sum(p_y_given_x), 1e-30)
            H_obs = 0.0
            for py in p_y_given_x
                if py > 1e-30
                    H_obs -= py * log(py)
                end
            end
            local_potential[x] *= exp(-H_obs)
        end
    end

    # Apply local potential to the MPS tensor
    # New A^x[k] = √(potential(x)) · A^x[k]
    # (square root because q(x) = ψ(x)², so multiplying amplitude by √w
    #  multiplies probability by w)
    for x in 1:d
        w = sqrt(max(local_potential[x], 1e-30))
        A[:, x, :] .*= w
    end

    ψ.tensors[k] = MPSTensor(A)

    # SVD to restore canonical form and push residual
    if direction == :left && k < nsites(ψ)
        # Left canonical: QR decomposition, push R to right
        A_new = ψ.tensors[k].data
        χL, d_k, χR = size(A_new)
        mat = reshape(A_new, χL * d_k, χR)

        F = svd(mat)
        χ_new = min(agent.bond_dim, length(F.S))
        U = F.U[:, 1:χ_new]
        SV = Diagonal(F.S[1:χ_new]) * F.Vt[1:χ_new, :]

        ψ.tensors[k] = MPSTensor(reshape(U, χL, d_k, χ_new))

        # Absorb into next site
        A_next = ψ.tensors[k+1].data
        χR_old, d_next, χR_next = size(A_next)
        A_next_mat = reshape(A_next, χR_old, d_next * χR_next)
        new_next = SV * A_next_mat
        ψ.tensors[k+1] = MPSTensor(reshape(new_next, χ_new, d_next, χR_next))

    elseif direction == :right && k > 1
        # Right canonical: SVD, push US to left
        A_new = ψ.tensors[k].data
        χL, d_k, χR = size(A_new)
        mat = reshape(A_new, χL, d_k * χR)

        F = svd(mat)
        χ_new = min(agent.bond_dim, length(F.S))
        US = F.U[:, 1:χ_new] * Diagonal(F.S[1:χ_new])
        Vt = F.Vt[1:χ_new, :]

        ψ.tensors[k] = MPSTensor(reshape(Vt, χ_new, d_k, χR))

        # Absorb into previous site
        A_prev = ψ.tensors[k-1].data
        χL_prev, d_prev, χR_prev = size(A_prev)
        A_prev_mat = reshape(A_prev, χL_prev * d_prev, χR_prev)
        new_prev = A_prev_mat * US
        ψ.tensors[k-1] = MPSTensor(reshape(new_prev, χL_prev, d_prev, χ_new))
    end
end

# ══════════════════════════════════════════════════════════════════════════════
# Full Inference Loop (Algorithm 1)
# ══════════════════════════════════════════════════════════════════════════════

"""
    infer_policy!(agent::MPSBeliefAgent) → Vector{Float64}

Implement Algorithm 1: EFE minimization as VFE minimization.

Returns the policy posterior q(u) as a probability vector over actions.

Algorithm:
1. Initialize q₀ as product state (done in agent construction)
2. For τ = 1 to τ_max:
   a. Compute epistemic priors p̃τ from qτ₋₁
   b. Run variational sweep (message passing) to get qτ
3. Extract policy posterior from final belief
"""
function infer_policy!(agent::MPSBeliefAgent{T}) where T
    n_actions = agent.n_actions
    τ_max = agent.n_iterations

    # Policy posterior: accumulate evidence for each action
    action_scores = zeros(T, n_actions)

    for u in 1:n_actions
        # Reset belief to initial state
        agent.belief = initialize_product_state(
            agent.n_states, agent.horizon, agent.bond_dim
        )

        # Iterative variational inference
        for τ in 1:τ_max
            # Apply transition for this action at each future timestep
            for t in 2:agent.horizon
                apply_transition!(agent, u, t)
            end

            # Variational sweep with epistemic + preference priors
            variational_sweep!(agent; n_sweeps=1)
        end

        # Score this action: negative VFE ≈ Rényi entropy + preference overlap
        entropy_score = renyi2_entropy_mps(agent.belief)

        # Preference overlap: ∑_t ⟨q(xₜ)|p̂(xₜ)⟩
        pref_score = 0.0
        for t in 1:agent.horizon
            marginal = local_marginal(agent.belief, t)
            pref_score += dot(marginal, agent.preference)
        end

        action_scores[u] = pref_score + entropy_score
    end

    # Softmax to get policy posterior
    action_scores .-= maximum(action_scores)  # numerical stability
    policy = exp.(action_scores)
    policy ./= sum(policy)

    return policy
end

# ══════════════════════════════════════════════════════════════════════════════
# Convenience Constructor
# ══════════════════════════════════════════════════════════════════════════════

"""
    create_mps_agent(;
        n_states, n_actions, horizon, bond_dim=16,
        transition_matrices, observation_model, preference,
        n_iterations=20
    ) → MPSBeliefAgent

Create a fully configured MPS-based active inference agent.

Arguments:
- n_states: number of discrete states (d)
- n_actions: number of available actions
- horizon: planning horizon T
- bond_dim: MPS bond dimension χ (default 16)
- transition_matrices: Dict{Int, Matrix} mapping action → transition matrix
- observation_model: Matrix (d_obs × d_state)
- preference: Vector of length d (goal prior)
- n_iterations: number of VI iterations (default 20)
"""
function create_mps_agent(;
    n_states::Int,
    n_actions::Int,
    horizon::Int,
    bond_dim::Int = 16,
    transition_matrices::Dict{Int, Matrix{T}},
    observation_model::Matrix{T},
    preference::Vector{T},
    n_iterations::Int = 20
) where T

    # Initialize belief as product state
    belief = initialize_product_state(n_states, horizon, bond_dim)

    # Convert transition matrices to MPOs
    transitions = Dict{Int, MPO{T}}()
    for (u, T_mat) in transition_matrices
        # For simplicity, apply at timestep 2 (first transition)
        transitions[u] = transition_to_mpo(T_mat, 2, horizon)
    end

    return MPSBeliefAgent{T}(
        belief,
        transitions,
        observation_model,
        preference,
        bond_dim,
        n_states,
        horizon,
        n_actions,
        n_iterations
    )
end

end # module MPSAgent
