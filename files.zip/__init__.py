"""
mps_pymdp — Matrix Product State backend for Active Inference (pymdp-compatible)

Drop-in replacement for pymdp.agent.Agent that uses tensor network
compression to scale active inference to exponentially larger state spaces.

Usage:
    from mps_pymdp import MPSAgent
    agent = MPSAgent(A=A, B=B, C=C, bond_dim=16)
    
    # Identical API to pymdp.agent.Agent:
    qs = agent.infer_states(observation)
    q_pi, G = agent.infer_policies()
    action = agent.sample_action()
"""

from .mps_agent import MPSAgent
from .mps_core import (
    MPS, MPO,
    mps_product_state, mps_from_dense, mps_to_dense,
    local_marginal, all_marginals,
    renyi2_entropy, shannon_entropy_site,
    svd_truncate, left_canonicalize,
)

__version__ = "0.1.0"
__all__ = [
    "MPSAgent",
    "MPS", "MPO",
    "mps_product_state", "mps_from_dense", "mps_to_dense",
    "local_marginal", "all_marginals",
    "renyi2_entropy", "shannon_entropy_site",
    "svd_truncate", "left_canonicalize",
]
