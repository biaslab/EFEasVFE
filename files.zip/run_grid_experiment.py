#!/usr/bin/env python3
"""
run_grid_experiment.py — Stochastic Grid World with MPS Active Inference

Reproduces the stochastic grid experiment from Nuijten et al. (2025)
"A Message Passing Realization of Expected Free Energy Minimization"

Runs BOTH:
  1. Dense agent (pymdp-compatible, exact inference)
  2. MPS agent (tensor network compressed beliefs)

and compares their performance, demonstrating that the MPS agent
reproduces the dense agent's behavior on small grids and scales to
larger grids where the dense agent fails.

The experiment loop follows pymdp's standard pattern:
    for episode in range(n_episodes):
        obs = env.reset()
        for t in range(horizon):
            qs = agent.infer_states(obs)
            q_pi, G = agent.infer_policies()
            action = agent.sample_action()
            obs = env.step(action)
"""

import numpy as np
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mps_pymdp.mps_agent import MPSAgent, obj_array, softmax, spm_log


# ═══════════════════════════════════════════════════════════════════════════════
# Environment: Stochastic Grid World (matches paper's Section 5.1)
# ═══════════════════════════════════════════════════════════════════════════════

class StochasticGridEnv:
    """Stochastic grid-world POMDP matching the EFEasVFE paper.
    
    Features:
    - NxN grid with 5 actions (up, right, down, left, stay)
    - Stochastic transitions on diagonal cells (risk of sink states)
    - Observation noise on cells near stochastic transitions
    - Goal cell with positive reward
    - Sink cells with negative reward (absorbing)
    - Shorter path goes through stochastic cells (risk/reward tradeoff)
    - Longer safe path avoids all stochasticity
    """
    
    UP, RIGHT, DOWN, LEFT, STAY = 0, 1, 2, 3, 4
    ACTION_NAMES = ["↑", "→", "↓", "←", "·"]
    
    def __init__(self, grid_size=4, stochasticity=0.3, obs_noise=0.15, seed=None):
        self.grid_size = grid_size
        self.N = grid_size
        self.n_states = grid_size ** 2
        self.n_actions = 5
        self.stochasticity = stochasticity
        self.obs_noise = obs_noise
        
        if seed is not None:
            np.random.seed(seed)
        
        # State layout
        self.start = 0  # top-left
        self.goal = self.n_states - 1  # bottom-right
        
        # Sink states: two corners
        self.sinks = [
            self._rc_to_idx(0, grid_size - 1),  # top-right
            self._rc_to_idx(grid_size - 1, 0),   # bottom-left
        ]
        
        # Stochastic cells: diagonal (shortest path)
        self.stochastic_cells = [
            self._rc_to_idx(i, i) for i in range(1, grid_size - 1)
        ]
        
        # Noisy observation cells: neighbors of stochastic cells
        self.noisy_cells = set()
        for s in self.stochastic_cells:
            r, c = self._idx_to_rc(s)
            for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                nr, nc = r+dr, c+dc
                if 0 <= nr < grid_size and 0 <= nc < grid_size:
                    ns = self._rc_to_idx(nr, nc)
                    if ns not in self.stochastic_cells and ns not in self.sinks:
                        self.noisy_cells.add(ns)
        
        self.state = self.start
        
        # Build POMDP model (A, B, C, D in pymdp format)
        self._build_model()
    
    def _rc_to_idx(self, r, c):
        return r * self.N + c
    
    def _idx_to_rc(self, idx):
        return idx // self.N, idx % self.N
    
    def _build_model(self):
        """Construct A, B, C, D matrices in pymdp format."""
        d = self.n_states
        
        # ── B matrix: transition likelihood ──
        # B[0] shape: (n_states, n_states, n_actions)
        B = obj_array(1)
        B[0] = np.zeros((d, d, self.n_actions))
        
        deltas = [(-1,0), (0,1), (1,0), (0,-1), (0,0)]  # up,right,down,left,stay
        
        for u in range(self.n_actions):
            dr, dc = deltas[u]
            for s in range(d):
                r, c = self._idx_to_rc(s)
                
                # Absorbing states
                if s in self.sinks or s == self.goal:
                    B[0][s, s, u] = 1.0
                    continue
                
                # Intended next state
                nr = np.clip(r + dr, 0, self.N - 1)
                nc = np.clip(c + dc, 0, self.N - 1)
                ns = self._rc_to_idx(nr, nc)
                
                if s in self.stochastic_cells:
                    # Stochastic: risk of falling into nearest sink
                    nearest_sink = min(self.sinks,
                        key=lambda sk: abs(self._idx_to_rc(sk)[0] - r) + 
                                       abs(self._idx_to_rc(sk)[1] - c))
                    B[0][ns, s, u] += 1.0 - self.stochasticity
                    B[0][nearest_sink, s, u] += self.stochasticity
                else:
                    B[0][ns, s, u] = 1.0
            
            # Normalize columns
            for s in range(d):
                col_sum = B[0][:, s, u].sum()
                if col_sum > 0:
                    B[0][:, s, u] /= col_sum
        
        self.B = B
        
        # ── A matrix: observation likelihood ──
        # Single modality: observe grid position (possibly noisy)
        A = obj_array(1)
        A[0] = np.zeros((d, d))
        
        for s in range(d):
            if s in self.noisy_cells:
                # Noisy observation
                A[0][:, s] = self.obs_noise / d
                A[0][s, s] = 1.0 - self.obs_noise + self.obs_noise / d
            else:
                # Perfect observation
                A[0][s, s] = 1.0 - self.obs_noise * 0.5
                A[0][:, s] += self.obs_noise * 0.5 / d
            
            # Normalize
            A[0][:, s] /= A[0][:, s].sum()
        
        self.A = A
        
        # ── C matrix: preferences (log-prior on observations) ──
        # Use distance-shaped preferences so agent has gradient toward goal
        C = obj_array(1)
        C[0] = np.zeros(d)
        goal_r, goal_c = self._idx_to_rc(self.goal)
        for s in range(d):
            r, c = self._idx_to_rc(s)
            manhattan = abs(r - goal_r) + abs(c - goal_c)
            max_dist = 2 * (self.N - 1)
            C[0][s] = 3.0 * (1.0 - manhattan / max_dist)  # gradient toward goal
        C[0][self.goal] = 6.0    # strongly prefer goal
        for sk in self.sinks:
            C[0][sk] = -6.0      # strongly avoid sinks
        
        self.C = C
        
        # ── D matrix: initial state prior ──
        D = obj_array(1)
        D[0] = np.zeros(d)
        D[0][self.start] = 1.0
        
        self.D = D
    
    def reset(self):
        """Reset environment. Returns initial observation."""
        self.state = self.start
        return [self._sample_observation(self.state)]
    
    def step(self, action):
        """Take action, return (observation, reward, done, info)."""
        action_idx = int(action[0]) if hasattr(action, '__len__') else int(action)
        
        # Sample next state from transition
        probs = self.B[0][:, self.state, action_idx]
        self.state = np.random.choice(self.n_states, p=probs)
        
        # Reward
        reward = 0.0
        done = False
        if self.state == self.goal:
            reward = 1.0
            done = True
        elif self.state in self.sinks:
            reward = -1.0
            done = True
        
        obs = [self._sample_observation(self.state)]
        return obs, reward, done, {"state": self.state}
    
    def _sample_observation(self, state):
        """Sample observation from A matrix."""
        probs = self.A[0][:, state]
        return np.random.choice(self.n_states, p=probs)
    
    def render_trajectory(self, trajectory, title=""):
        """ASCII render of the grid with trajectory."""
        grid = [['.' for _ in range(self.N)] for _ in range(self.N)]
        
        # Mark special cells
        for s in self.sinks:
            r, c = self._idx_to_rc(s)
            grid[r][c] = 'X'
        for s in self.stochastic_cells:
            r, c = self._idx_to_rc(s)
            grid[r][c] = '~'
        r, c = self._idx_to_rc(self.goal)
        grid[r][c] = 'G'
        r, c = self._idx_to_rc(self.start)
        grid[r][c] = 'S'
        
        # Mark trajectory
        for i, s in enumerate(trajectory):
            r, c = self._idx_to_rc(s)
            if grid[r][c] in '.~':
                grid[r][c] = str(i % 10)
        
        print(f"\n  {title}")
        print("  +" + "--" * self.N + "+")
        for row in grid:
            print("  |" + " ".join(row) + "|")
        print("  +" + "--" * self.N + "+")


# ═══════════════════════════════════════════════════════════════════════════════
# Dense Agent (reference, equivalent to pymdp.agent.Agent)
# ═══════════════════════════════════════════════════════════════════════════════

class DenseAgent:
    """Simple dense active inference agent for comparison.
    
    This implements the same inference as pymdp.agent.Agent but with
    minimal code, so we can compare against MPSAgent without requiring
    pymdp installation.
    """
    
    def __init__(self, A, B, C, D, gamma=16.0, use_epistemic=True):
        self.A = A
        self.B = B
        self.C = C
        self.D = D
        self.gamma = gamma
        self.use_epistemic = use_epistemic
        
        self.n_states = B[0].shape[0]
        self.n_actions = B[0].shape[2]
        self.num_factors = 1
        self.num_modalities = 1
        
        self.qs = D[0].copy()
        self.prev_action = None
    
    def infer_states(self, observation):
        obs_idx = observation[0]
        
        # Likelihood
        likelihood = self.A[0][obs_idx, :]
        
        # Prior from transition
        if self.prev_action is not None:
            prior = self.B[0][:, :, self.prev_action] @ self.qs
        else:
            prior = self.D[0]
        
        # Posterior: softmax of log-likelihood + log-prior
        log_post = np.log(np.maximum(likelihood, 1e-16)) + \
                   np.log(np.maximum(prior, 1e-16))
        self.qs = softmax(log_post)
        return self.qs
    
    def infer_policies(self):
        G = np.zeros(self.n_actions)
        
        for u in range(self.n_actions):
            qs_next = self.B[0][:, :, u] @ self.qs
            qs_next /= max(qs_next.sum(), 1e-30)
            
            # Predicted observations
            qo = self.A[0] @ qs_next
            qo /= max(qo.sum(), 1e-30)
            
            # Utility: E[ln C]
            lnC = spm_log(softmax(self.C[0]))
            G[u] += np.sum(qo * lnC)
            
            # Epistemic: info gain
            if self.use_epistemic:
                H_qo = -np.sum(qo * np.log(np.maximum(qo, 1e-30)))
                H_cond = 0.0
                for s in range(self.n_states):
                    p_o_s = self.A[0][:, s]
                    p_o_s /= max(p_o_s.sum(), 1e-30)
                    h = -np.sum(p_o_s * np.log(np.maximum(p_o_s, 1e-30)))
                    H_cond += qs_next[s] * h
                G[u] += H_qo - H_cond
        
        q_pi = softmax(self.gamma * G)
        return q_pi, G
    
    def sample_action(self, q_pi):
        action = np.argmax(q_pi)
        self.prev_action = action
        return action
    
    def reset(self):
        self.qs = self.D[0].copy()
        self.prev_action = None


# ═══════════════════════════════════════════════════════════════════════════════
# Experiment Runner
# ═══════════════════════════════════════════════════════════════════════════════

def run_experiment(grid_size=4, n_episodes=50, horizon=15, bond_dim=16,
                   stochasticity=0.3, obs_noise=0.15, seed=42):
    """Run the full comparative experiment."""
    
    np.random.seed(seed)
    
    print("=" * 70)
    print(f"  STOCHASTIC GRID EXPERIMENT — {grid_size}×{grid_size} grid")
    print(f"  Episodes: {n_episodes}  Horizon: {horizon}  Bond dim χ={bond_dim}")
    print(f"  Stochasticity: {stochasticity}  Obs noise: {obs_noise}")
    print("=" * 70)
    
    env = StochasticGridEnv(grid_size, stochasticity, obs_noise, seed)
    
    # Print grid layout
    env.render_trajectory([], "Grid Layout (S=start, G=goal, X=sink, ~=stochastic)")
    
    # ── Dense EFE Agent ──
    print("\n━━━ Dense EFE Agent (reference) ━━━")
    dense_efe = DenseAgent(env.A, env.B, env.C, env.D, use_epistemic=True)
    dense_efe_results = _run_episodes(env, dense_efe, n_episodes, horizon, "Dense-EFE")
    
    # ── Dense KL-Control Agent (no epistemic) ──
    print("\n━━━ Dense KL-Control Agent (no epistemic) ━━━")
    dense_kl = DenseAgent(env.A, env.B, env.C, env.D, use_epistemic=False)
    dense_kl_results = _run_episodes(env, dense_kl, n_episodes, horizon, "Dense-KL")
    
    # ── MPS EFE Agent ──
    print(f"\n━━━ MPS EFE Agent (χ={bond_dim}) ━━━")
    mps_efe = MPSAgent(
        A=env.A, B=env.B, C=env.C, D=env.D,
        bond_dim=bond_dim,
        use_epistemic=True,
        action_selection="deterministic",
        gamma=16.0,
    )
    mps_efe_results = _run_episodes(env, mps_efe, n_episodes, horizon, "MPS-EFE")
    
    # ── MPS KL-Control Agent ──
    print(f"\n━━━ MPS KL-Control Agent (χ={bond_dim}, no epistemic) ━━━")
    mps_kl = MPSAgent(
        A=env.A, B=env.B, C=env.C, D=env.D,
        bond_dim=bond_dim,
        use_epistemic=False,
        action_selection="deterministic",
        gamma=16.0,
    )
    mps_kl_results = _run_episodes(env, mps_kl, n_episodes, horizon, "MPS-KL")
    
    # ── Summary ──
    print("\n" + "=" * 70)
    print("  RESULTS SUMMARY")
    print("=" * 70)
    print(f"  {'Agent':<20} {'Success%':>10} {'Avg Reward':>12} {'Avg Steps':>10}")
    print("  " + "-" * 54)
    
    for name, results in [("Dense-EFE", dense_efe_results), 
                           ("Dense-KL", dense_kl_results),
                           ("MPS-EFE", mps_efe_results),
                           ("MPS-KL", mps_kl_results)]:
        success = np.mean([r["success"] for r in results]) * 100
        avg_reward = np.mean([r["total_reward"] for r in results])
        avg_steps = np.mean([r["steps"] for r in results])
        print(f"  {name:<20} {success:>9.1f}% {avg_reward:>11.3f} {avg_steps:>10.1f}")
    
    # ── MPS Diagnostics ──
    print(f"\n  MPS compression ratio: {mps_efe.compression_ratio:.1f}x")
    print(f"  MPS bond dimensions: {mps_efe.bond_dimensions}")
    print(f"  MPS belief entropy: {mps_efe.belief_entropy:.4f}")
    
    # Memory comparison
    dense_params = env.n_states  # just the belief vector
    mps_params = sum(np.prod(t.shape) for t in mps_efe.belief_mps.tensors)
    print(f"\n  Dense belief: {dense_params} parameters")
    print(f"  MPS belief:   {mps_params} parameters")
    
    if grid_size <= 6:
        # Show example trajectories
        print("\n  Example trajectory (episode 1):")
        if dense_efe_results:
            env.render_trajectory(dense_efe_results[0]["trajectory"], "Dense-EFE")
        if mps_efe_results:
            env.render_trajectory(mps_efe_results[0]["trajectory"], "MPS-EFE")
    
    print("\n  ✓ Experiment complete")
    return dense_efe_results, dense_kl_results, mps_efe_results, mps_kl_results


def _run_episodes(env, agent, n_episodes, horizon, name):
    """Run multiple episodes with an agent. Works with both Dense and MPS agents."""
    results = []
    is_mps = isinstance(agent, MPSAgent)
    
    for ep in range(n_episodes):
        if is_mps:
            agent.reset()
        else:
            agent.reset()
        
        obs = env.reset()
        total_reward = 0.0
        trajectory = [env.state]
        
        for t in range(horizon):
            # Infer states
            if is_mps:
                agent.infer_states(obs)
                q_pi, G = agent.infer_policies()
                action = agent.sample_action()
            else:
                agent.infer_states(obs)
                q_pi, G = agent.infer_policies()
                action_idx = agent.sample_action(q_pi)
                action = np.array([action_idx])
            
            # Step environment
            obs, reward, done, info = env.step(action)
            total_reward += reward
            trajectory.append(env.state)
            
            if done:
                break
        
        success = env.state == env.goal
        results.append({
            "success": success,
            "total_reward": total_reward,
            "steps": t + 1,
            "trajectory": trajectory,
        })
        
        if ep == 0:
            status = "✓ GOAL" if success else ("✗ SINK" if env.state in env.sinks else "✗ TIMEOUT")
            print(f"  Episode 1: {status} | steps={t+1} | reward={total_reward:.2f}")
    
    success_rate = np.mean([r["success"] for r in results])
    avg_reward = np.mean([r["total_reward"] for r in results])
    print(f"  → {name}: {success_rate*100:.0f}% success, avg reward {avg_reward:.3f} ({n_episodes} episodes)")
    
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MPS Active Inference Experiment")
    parser.add_argument("--grid-size", type=int, default=4)
    parser.add_argument("--bond-dim", type=int, default=16)
    parser.add_argument("--horizon", type=int, default=15)
    parser.add_argument("--n-episodes", type=int, default=50)
    parser.add_argument("--stochasticity", type=float, default=0.3)
    parser.add_argument("--obs-noise", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    
    run_experiment(
        grid_size=args.grid_size,
        n_episodes=args.n_episodes,
        horizon=args.horizon,
        bond_dim=args.bond_dim,
        stochasticity=args.stochasticity,
        obs_noise=args.obs_noise,
        seed=args.seed,
    )
