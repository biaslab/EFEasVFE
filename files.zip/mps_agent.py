"""
mps_agent.py — Drop-in replacement for pymdp.agent.Agent using MPS beliefs

This class provides the EXACT SAME API as pymdp's Agent:
    - __init__(A, B, C, D, ...)
    - infer_states(observation) -> qs
    - infer_policies() -> (q_pi, G)  
    - sample_action() -> action

The key difference: internally, beliefs are stored as MPS (tensor trains)
instead of dense numpy arrays, enabling scaling to exponentially larger
state spaces.

Usage (drop-in replacement):
    # Before (pymdp):
    from pymdp.agent import Agent
    agent = Agent(A=A, B=B, C=C)
    
    # After (MPS):
    from mps_pymdp.mps_agent import MPSAgent
    agent = MPSAgent(A=A, B=B, C=C, bond_dim=16)
    
    # Same API from here:
    qs = agent.infer_states(observation)
    q_pi, G = agent.infer_policies()
    action = agent.sample_action()
"""

import numpy as np
from numpy.linalg import norm
from typing import List, Optional, Tuple, Union
from copy import deepcopy

from .mps_core import (
    MPS, MPO, 
    mps_product_state, mps_from_dense, mps_to_dense,
    local_marginal, all_marginals,
    transition_matrix_to_mpo, apply_mpo_to_site,
    apply_local_potential, variational_sweep,
    svd_truncate, left_canonicalize,
    renyi2_entropy, shannon_entropy_site, observation_entropy,
)
import numpy.linalg


def softmax(x):
    """Numerically stable softmax."""
    e = np.exp(x - np.max(x))
    return e / max(e.sum(), 1e-30)


def spm_log(x):
    """Numerically stable log (SPM convention, matching pymdp)."""
    return np.log(np.maximum(x, 1e-16))


def obj_array(n):
    """Create pymdp-style object array."""
    return np.empty(n, dtype=object)


def obj_array_uniform(dims):
    """Create uniform object array (pymdp convention)."""
    arr = obj_array(len(dims))
    for i, d in enumerate(dims):
        arr[i] = np.ones(d) / d
    return arr


class MPSAgent:
    """Active Inference agent with MPS-compressed beliefs.
    
    This is a drop-in replacement for pymdp.agent.Agent.
    All public methods have identical signatures and return types.
    
    The internal belief representation uses Matrix Product States instead
    of dense vectors, replacing O(d^N) storage with O(N * d * chi^2).
    
    Args:
        A: Observation likelihood. Object array of matrices A[m] with shape
           (num_obs[m], *num_states) for each modality m.
        B: Transition likelihood. Object array of matrices B[f] with shape
           (num_states[f], num_states[f], num_controls[f]) for each factor f.
        C: Observation preferences (log-prior on observations).
           Object array of vectors C[m] with shape (num_obs[m],).
        D: Initial state prior. Object array of vectors D[f] with 
           shape (num_states[f],).
        
        bond_dim: MPS bond dimension chi (controls compression vs accuracy).
                  Higher = more accurate but slower. Default: 16.
        n_vi_iterations: Number of variational inference iterations. Default: 16.
        policy_len: Temporal depth of policies. Default: 1.
        gamma: Policy precision (inverse temperature). Default: 16.0.
        use_epistemic: Whether to include epistemic (information gain) terms
                       in expected free energy. Default: True. 
                       Set False to get KL-control behavior.
    """
    
    def __init__(
        self,
        A: np.ndarray,
        B: np.ndarray,
        C: Optional[np.ndarray] = None,
        D: Optional[np.ndarray] = None,
        E: Optional[np.ndarray] = None,
        policies: Optional[np.ndarray] = None,
        bond_dim: int = 16,
        n_vi_iterations: int = 16,
        policy_len: int = 1,
        inference_horizon: int = 1,
        gamma: float = 16.0,
        use_epistemic: bool = True,
        use_utility: bool = True,
        inference_algo: str = "VANILLA",
        action_selection: str = "deterministic",
    ):
        # ── Store generative model (same format as pymdp) ──
        self.A = A
        self.B = B
        
        # Derive dimensions
        self.num_modalities = len(A)
        self.num_obs = [A[m].shape[0] for m in range(self.num_modalities)]
        
        self.num_factors = len(B)
        self.num_states = [B[f].shape[0] for f in range(self.num_factors)]
        self.num_controls = [B[f].shape[2] for f in range(self.num_factors)]
        
        # Preferences
        if C is not None:
            self.C = C
        else:
            self.C = obj_array_uniform(self.num_obs)
        
        # Initial state prior
        if D is not None:
            self.D = D
        else:
            self.D = obj_array(self.num_factors)
            for f in range(self.num_factors):
                self.D[f] = np.ones(self.num_states[f]) / self.num_states[f]
        
        # Policy prior (E vector in pymdp)
        self.E = E
        
        # ── MPS-specific parameters ──
        self.bond_dim = bond_dim
        self.n_vi_iterations = n_vi_iterations
        self.policy_len = policy_len
        self.inference_horizon = inference_horizon
        self.gamma = gamma
        self.use_epistemic = use_epistemic
        self.use_utility = use_utility
        self.inference_algo = inference_algo
        self.action_selection = action_selection
        
        # ── Initialize beliefs as MPS ──
        # For VANILLA inference: qs[f] are independent marginals  
        # We store them both as MPS (for tensor operations) and as 
        # dense marginals (for pymdp compatibility)
        self._init_beliefs()
        
        # ── Construct policies ──
        if policies is not None:
            self.policies = policies
        else:
            self.policies = self._construct_policies()
        
        self.q_pi = np.ones(len(self.policies)) / len(self.policies)
        self.G = np.zeros(len(self.policies))
        self.prev_actions = None
        self.action = None
        self.curr_timestep = 0
    
    def _init_beliefs(self):
        """Initialize posterior beliefs as MPS product state."""
        # MPS representation of joint belief q(s1, s2, ..., sF)
        self.belief_mps = mps_product_state(
            self.num_states,
            probs=[self.D[f] for f in range(self.num_factors)],
            bond_dim=self.bond_dim
        )
        
        # Also maintain pymdp-compatible dense marginals
        self.qs = obj_array(self.num_factors)
        for f in range(self.num_factors):
            self.qs[f] = self.D[f].copy()
    
    def _construct_policies(self) -> np.ndarray:
        """Construct all possible policies (matching pymdp's construct_policies).
        
        A policy is a sequence of actions over policy_len timesteps.
        For policy_len=1: each policy is just a single action combination.
        """
        from itertools import product as cartesian_product
        
        action_combos = list(cartesian_product(
            *[range(nc) for nc in self.num_controls]
        ))
        
        if self.policy_len == 1:
            policies = np.array(action_combos).reshape(-1, 1, self.num_factors)
        else:
            # All sequences of length policy_len
            policy_seqs = list(cartesian_product(action_combos, repeat=self.policy_len))
            policies = np.array(policy_seqs).reshape(-1, self.policy_len, self.num_factors)
        
        return policies
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC API: Exact match with pymdp.agent.Agent
    # ═══════════════════════════════════════════════════════════════════════════
    
    def infer_states(self, observation: Union[list, tuple], 
                     distr_obs: bool = False) -> np.ndarray:
        """Update posterior beliefs given an observation.
        
        REPLACES pymdp's dense Bayesian update:
            qs[f] = softmax(log(A[o,:]) + log(B[:,:,u] @ qs_prev[f]))
        WITH MPS variational update:
            belief_mps = variational_sweep(belief_mps, potentials)
        
        Args:
            observation: list of observation indices, one per modality.
                         observation[m] = index of observation for modality m.
            distr_obs: whether observation is already a distribution.
            
        Returns:
            qs: object array of marginals, qs[f] shape (num_states[f],).
                IDENTICAL format to pymdp.
        """
        # Construct observation potentials for each factor
        # pymdp: log_likelihood = log(A[m][o_m, :])  (summed over modalities)
        potentials = [np.ones(self.num_states[f]) for f in range(self.num_factors)]
        
        for m in range(self.num_modalities):
            A_m = self.A[m]  # shape: (num_obs[m], num_states[0], ..., num_states[F-1])
            
            if distr_obs:
                obs_vec = observation[m]
            else:
                obs_idx = observation[m]
                obs_vec = np.zeros(self.num_obs[m])
                obs_vec[obs_idx] = 1.0
            
            # For each factor, marginalize the likelihood over other factors
            for f in range(self.num_factors):
                if A_m.ndim == 2:
                    # Simple case: A[m] is (num_obs, num_states) for single factor
                    if not distr_obs:
                        likelihood_f = A_m[obs_idx, :]
                    else:
                        likelihood_f = obs_vec @ A_m
                else:
                    # Multi-factor case: marginalize over other factors using current qs
                    # A_m has shape (num_obs[m], ns[0], ns[1], ..., ns[F-1])
                    # Contract all factors except f with their current beliefs
                    contracted = A_m.copy()
                    if not distr_obs:
                        contracted = contracted[obs_idx]  # shape: (ns[0], ..., ns[F-1])
                    else:
                        contracted = np.tensordot(obs_vec, contracted, axes=([0], [0]))
                    
                    for g in range(self.num_factors):
                        if g != f:
                            # Sum over factor g weighted by current belief
                            axis = g if g < f else g  
                            # Adjust axis for already-contracted dimensions
                            adj_axis = g - sum(1 for h in range(g) if h != f and h < g)
                            contracted = np.tensordot(
                                self.qs[g], contracted, 
                                axes=([0], [g if g < contracted.ndim else -1])
                            )
                    
                    likelihood_f = contracted.flatten()[:self.num_states[f]]
                
                potentials[f] *= np.maximum(likelihood_f, 1e-16)
        
        # Add prior from transition model (if we have previous actions)
        if self.prev_actions is not None:
            for f in range(self.num_factors):
                u = int(self.prev_actions[f])
                B_u = self.B[f][:, :, u]  # (ns, ns) transition matrix
                prior_f = B_u @ self.qs[f]
                potentials[f] *= np.maximum(prior_f, 1e-16)
        else:
            for f in range(self.num_factors):
                potentials[f] *= np.maximum(self.D[f], 1e-16)
        
        # ── MPS variational update ──
        # For each factor, compute the posterior via the standard update:
        #   qs[f] = softmax(log(likelihood_f) + log(prior_f))
        # Then update the MPS site tensor to reflect this posterior.
        #
        # This is equivalent to pymdp's update but stores the result
        # in MPS form, enabling tensor-network operations downstream.
        
        self.qs = obj_array(self.num_factors)
        new_tensors = [t.copy() for t in self.belief_mps.tensors]
        
        for f in range(self.num_factors):
            # The potential already contains likelihood * prior
            log_post = np.log(np.maximum(potentials[f], 1e-16))
            self.qs[f] = softmax(log_post)
            
            # Update the MPS site tensor for this factor
            amp = np.sqrt(np.maximum(self.qs[f], 0.0))
            amp /= max(np.linalg.norm(amp), 1e-30)
            
            # For single-site or product-state regime: shape (chi_L, d, chi_R)
            chi_L = new_tensors[f].shape[0]
            chi_R = new_tensors[f].shape[2]
            
            if chi_L == 1 and chi_R == 1:
                # Simple case: just set the amplitudes directly
                new_tensors[f] = amp.reshape(1, -1, 1)
            else:
                # Entangled case: apply potential as diagonal and re-normalize
                new_tensors[f] = apply_local_potential(
                    MPS(new_tensors, self.bond_dim), f, self.qs[f]
                ).tensors[f]
        
        self.belief_mps = MPS(new_tensors, self.bond_dim)
        
        return self.qs
    
    def infer_policies(self) -> Tuple[np.ndarray, np.ndarray]:
        """Compute posterior over policies using Expected Free Energy.
        
        REPLACES pymdp's dense EFE computation with MPS-based calculation.
        
        The Expected Free Energy G(pi) for policy pi decomposes into:
            G(pi) = E[ambiguity] - E[utility]  (pragmatic)
                   + E[state info gain]          (epistemic, Eq. 13a)
                   + E[parameter info gain]      (epistemic, Eq. 13b)
        
        Returns:
            q_pi: posterior over policies, shape (n_policies,)
            G: negative expected free energy per policy, shape (n_policies,)
        """
        n_policies = len(self.policies)
        G = np.zeros(n_policies)
        
        for idx, policy in enumerate(self.policies):
            G[idx] = self._compute_G_for_policy(policy)
        
        # Policy posterior: q(pi) = softmax(gamma * G + ln E)
        log_prior = np.zeros(n_policies)
        if self.E is not None:
            log_prior = spm_log(self.E)
        
        q_pi = softmax(self.gamma * G + log_prior)
        
        self.q_pi = q_pi
        self.G = G
        
        return q_pi, G
    
    def _compute_G_for_policy(self, policy: np.ndarray) -> float:
        """Compute negative expected free energy for a single policy.
        
        policy shape: (policy_len, num_factors) — action indices per timestep
        
        This is where the MPS advantage is greatest for long horizons:
        dense EFE requires summing over d^T state sequences, while
        MPS-EFE contracts through the tensor train in O(T * d * chi^2).
        """
        G = 0.0
        
        # Forward simulate beliefs under this policy using MPS
        qs_pi = [self.qs[f].copy() for f in range(self.num_factors)]
        
        for t in range(self.policy_len):
            # Predict next state: qs_next[f] = B[f][:,:,u_t] @ qs[f]
            qs_next = []
            for f in range(self.num_factors):
                u = int(policy[t, f])
                B_u = self.B[f][:, :, u]
                qs_next_f = B_u @ qs_pi[f]
                qs_next_f /= max(qs_next_f.sum(), 1e-30)
                qs_next.append(qs_next_f)
            
            # ── Pragmatic value (utility): E_q(s)[ln p(o|s)] weighted by preferences ──
            if self.use_utility:
                for m in range(self.num_modalities):
                    A_m = self.A[m]
                    C_m = self.C[m]
                    
                    if A_m.ndim == 2:
                        # Single factor: predicted observations
                        qo_m = A_m @ qs_next[0]
                    else:
                        # Multi-factor: contract A with predicted beliefs
                        qo_m = A_m.copy()
                        for f in range(self.num_factors):
                            qo_m = np.tensordot(qs_next[f], qo_m, axes=([0], [-1]))
                        qo_m = qo_m.flatten()[:self.num_obs[m]]
                    
                    qo_m /= max(qo_m.sum(), 1e-30)
                    
                    # Utility = E_q(o)[ln p(o)] = sum q(o) * ln C(o)
                    # where C is the softmax of preferences
                    lnC = spm_log(softmax(C_m))
                    G += np.sum(qo_m * lnC)
            
            # ── Epistemic value (information gain) ──
            if self.use_epistemic:
                for m in range(self.num_modalities):
                    A_m = self.A[m]
                    
                    if A_m.ndim == 2:
                        # State information gain:
                        # I(o;s) = H[q(o)] - E_q(s)[H[p(o|s)]]
                        qo_m = A_m @ qs_next[0]
                        qo_m /= max(qo_m.sum(), 1e-30)
                        
                        # Marginal entropy H[q(o)]
                        H_qo = -np.sum(qo_m * np.log(np.maximum(qo_m, 1e-30)))
                        
                        # Expected conditional entropy E_q(s)[H[p(o|s)]]
                        H_cond = observation_entropy(A_m, qs_next[0])
                        
                        # Information gain = H[q(o)] - E[H[p(o|s)]]
                        info_gain = H_qo - H_cond
                        G += info_gain  # Positive = more informative = preferred
                    else:
                        # Multi-factor: use per-factor approximation
                        for f in range(self.num_factors):
                            # Marginalize A over other factors
                            A_marg = A_m.copy()
                            for g in range(self.num_factors):
                                if g != f:
                                    A_marg = np.tensordot(
                                        qs_next[g], A_marg, axes=([0], [-1])
                                    )
                            A_marg = A_marg.reshape(self.num_obs[m], self.num_states[f])
                            
                            qo = A_marg @ qs_next[f]
                            qo /= max(qo.sum(), 1e-30)
                            H_qo = -np.sum(qo * np.log(np.maximum(qo, 1e-30)))
                            H_cond = observation_entropy(A_marg, qs_next[f])
                            G += H_qo - H_cond
            
            qs_pi = qs_next
        
        return G
    
    def sample_action(self) -> np.ndarray:
        """Sample an action from the policy posterior.
        
        IDENTICAL output format to pymdp: array of action indices,
        one per factor.
        
        Returns:
            action: 1-D array of ints, shape (num_factors,)
        """
        if self.action_selection == "deterministic":
            policy_idx = np.argmax(self.q_pi)
        else:
            policy_idx = np.random.choice(len(self.q_pi), p=self.q_pi)
        
        # Extract first timestep of selected policy
        action = self.policies[policy_idx][0, :]
        
        self.prev_actions = action.copy()
        self.action = action
        self.curr_timestep += 1
        
        return action
    
    def reset(self):
        """Reset beliefs to initial prior (start of new episode)."""
        self._init_beliefs()
        self.prev_actions = None
        self.action = None
        self.curr_timestep = 0
        self.q_pi = np.ones(len(self.policies)) / len(self.policies)
        self.G = np.zeros(len(self.policies))
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Convenience: step() method (combined infer + act, matches pymdp)
    # ═══════════════════════════════════════════════════════════════════════════
    
    def step(self, observation: Union[list, tuple]) -> np.ndarray:
        """One full active inference step: observe → infer → plan → act.
        
        Mirrors pymdp's typical usage loop:
            qs = agent.infer_states(obs)
            q_pi, G = agent.infer_policies()
            action = agent.sample_action()
        """
        self.infer_states(observation)
        self.infer_policies()
        return self.sample_action()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MPS-specific diagnostics (not in pymdp, but useful)
    # ═══════════════════════════════════════════════════════════════════════════
    
    @property
    def belief_entropy(self) -> float:
        """Rényi-2 entropy of the full joint belief MPS."""
        return renyi2_entropy(self.belief_mps)
    
    @property
    def bond_dimensions(self) -> List[int]:
        """Current bond dimensions at each bond in the MPS."""
        return [self.belief_mps.tensors[k].shape[2] 
                for k in range(self.belief_mps.nsites - 1)]
    
    @property
    def compression_ratio(self) -> float:
        """Ratio of dense parameters to MPS parameters."""
        dense = np.prod(self.num_states)
        mps_params = sum(np.prod(t.shape) for t in self.belief_mps.tensors)
        return dense / max(mps_params, 1)
