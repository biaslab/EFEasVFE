"""
    MPSEntropy.jl

    Operation B: Epistemic Prior — Entropy Calculation via MPS

    In the original EFEasVFE code, the epistemic priors require computing:
        p̃(xₜ) ∝ exp(−H[q(yₜ|xₜ)])           — observation entropy (Eq. 13b)
        p̃(uₜ) ∝ exp(H[q(xₜ,xₜ₋₁|uₜ)] − H[q(xₜ₋₁|uₜ)])  — transition entropy (Eq. 13a)

    where H[q] = −∑ q log q is the Shannon entropy.

    PROBLEM: For dense distributions over d^T states, computing ∑ q log q is O(d^T).

    SOLUTION: We use the Rényi-2 entropy as a computationally tractable proxy:
        S₂(ρ) = −ln(Tr(ρ²))

    For an MPS |ψ⟩ representing q(x) = |ψ(x)|², the purity Tr(ρ²) can be computed
    via a transfer matrix contraction in O(T · d · χ⁴) time — polynomial, not exponential.

    PHYSICS BACKGROUND:
    ─────────────────────
    Given an MPS:  |ψ⟩ = ∑_{x₁...xₜ} A^{x₁}[1] · A^{x₂}[2] ··· A^{xₜ}[T] |x₁...xₜ⟩

    The reduced density matrix for a bipartition at bond k is:
        ρ_L = Tr_R(|ψ⟩⟨ψ|)

    The purity is:
        Tr(ρ²) = contraction of the "double layer" transfer matrices

    For the FULL chain entropy (not bipartite), we need:
        Tr(ρ²) = ∑_x |ψ(x)|⁴ = ∑_x q(x)²

    This equals the contraction of the transfer matrix chain:
        T[k]_{(αα')(ββ')} = ∑_{xₖ} A^{xₖ}[k]_{αβ} · conj(A^{xₖ}[k])_{α'β'}
                           · conj(A^{xₖ}[k])_{αβ} · ... (double copy)

    We implement three entropy measures:
    1. Rényi-2 entropy via purity (fast, O(T·d·χ⁴))
    2. von Neumann entropy via singular values at a bond (for diagnostics)
    3. Approximate Shannon entropy via sampling (stochastic, for validation)
"""
module MPSEntropy

using LinearAlgebra

export renyi2_entropy_mps,
       vonneumann_entropy_bond,
       purity_mps,
       shannon_entropy_exact,
       local_entropy_mps,
       epistemic_prior_state,
       epistemic_prior_action

# ══════════════════════════════════════════════════════════════════════════════
# Data Structures
# ══════════════════════════════════════════════════════════════════════════════

"""
    MPSTensor

A single tensor in the MPS chain.
Shape: (χ_left, d, χ_right) where d is the physical dimension.

For the first site:  χ_left = 1  (row vector)
For the last site:   χ_right = 1 (column vector)
For interior sites:  χ_left, χ_right ≤ χ_max (bond dimension)
"""
struct MPSTensor{T<:Number}
    data::Array{T, 3}  # (χ_left, d, χ_right)
end

# Convenience accessors
bond_dim_left(A::MPSTensor) = size(A.data, 1)
phys_dim(A::MPSTensor) = size(A.data, 2)
bond_dim_right(A::MPSTensor) = size(A.data, 3)

"""
    MPS

A Matrix Product State representing a probability amplitude vector.
The probability distribution is q(x₁,...,xₜ) = |ψ(x₁,...,xₜ)|²
where ψ(x₁,...,xₜ) = A^{x₁}[1] · A^{x₂}[2] · ... · A^{xₜ}[T].

For Active Inference:
- Each site t corresponds to a timestep
- Physical dimension d = number of possible states at each timestep
- Bond dimension χ controls the approximation quality
"""
struct MPS{T<:Number}
    tensors::Vector{MPSTensor{T}}
    bond_dim::Int       # Maximum bond dimension χ
end

nsites(ψ::MPS) = length(ψ.tensors)

# ══════════════════════════════════════════════════════════════════════════════
# OPERATION B.1: Purity via Transfer Matrix Contraction
# ══════════════════════════════════════════════════════════════════════════════

"""
    transfer_matrix(A::MPSTensor)

Compute the transfer matrix for site k of the DOUBLE-COPY contraction.
This computes Tr(ρ²) = ∑_x q(x)² where q(x) = |ψ(x)|².

The transfer matrix T[k] acts on the doubled bond space (α,α') × (β,β'):

    T[k]_{(αα')(ββ')} = ∑_{xₖ} A^{xₖ}_{αβ} · Ā^{xₖ}_{α'β'} · A^{xₖ}_{αβ} · Ā^{xₖ}_{α'β'}

Wait — that's for Tr(ρ²) with the full density matrix. For the simpler case
of the purity of the diagonal distribution q(x) = |ψ(x)|², we need:

    Purity = ∑_{x₁...xₜ} (∑_bonds A^{x₁}·A^{x₂}·...·A^{xₜ})² × (c.c.)²

This is the contraction of four copies. Instead, we use the more efficient
approach for REAL, NORMALIZED MPS representing probability amplitudes:

For q(x) = ψ(x)² (real-valued amplitude MPS, ψ ≥ 0):
    Purity = ∑_x q(x)² = ∑_x ψ(x)⁴

The "fourth moment" transfer matrix is:
    T⁴[k]_{(α₁α₂)(β₁β₂)} = ∑_{xₖ} (A^{xₖ}_{α₁,β₁})² · (A^{xₖ}_{α₂,β₂})²

But this grows as χ⁴. A better approach: since q = ψ², define B^{xₖ} = (A^{xₖ})²
elementwise? No — matrix multiplication structure is lost.

CORRECT APPROACH: Work with the density-MPS directly.
If |ψ⟩ represents √q, then ρ_diag = q, and:
    Tr(ρ²) = ⟨ψ⊗ψ | ψ⊗ψ⟩ (with appropriate index contractions)

We compute this via the doubled transfer matrix:
    E[k]_{(αα')(ββ')} = ∑_{xₖ} A^{xₖ}_{αβ} · A^{xₖ}_{α'β'}

Then: Purity = (boundary) · E[1] · E[2] · ... · E[T] · (boundary)

Returns: Matrix of size (χ_L·χ_L) × (χ_R·χ_R)
"""
function transfer_matrix_doubled(A::MPSTensor{T}) where T
    χL = bond_dim_left(A)
    d  = phys_dim(A)
    χR = bond_dim_right(A)

    # E_{(α₁α₂),(β₁β₂)} = ∑_x A^x_{α₁β₁} · A^x_{α₂β₂}
    E = zeros(T, χL * χL, χR * χR)

    for x in 1:d
        # Extract the matrix A^x of shape (χL, χR)
        Ax = @view A.data[:, x, :]  # (χL, χR)

        # Outer product in the doubled space: (A^x ⊗ A^x)
        # E += vec(A^x) * vec(A^x)' ... but reshaped
        for α1 in 1:χL, α2 in 1:χL, β1 in 1:χR, β2 in 1:χR
            row = (α1 - 1) * χL + α2
            col = (β1 - 1) * χR + β2
            E[row, col] += Ax[α1, β1] * Ax[α2, β2]
        end
    end

    return E
end

"""
    purity_mps(ψ::MPS) → Float64

Compute the purity Tr(ρ²) = ∑_x q(x)² where q(x) = ψ(x)²
via transfer matrix contraction through the MPS chain.

Complexity: O(T · d · χ⁴)

For a properly normalized probability distribution:
- Purity = 1  → delta distribution (zero entropy)
- Purity = 1/D → uniform distribution over D states (max entropy)
"""
function purity_mps(ψ::MPS{T}) where T
    L = nsites(ψ)
    @assert L ≥ 1 "MPS must have at least one site"

    # Start from left boundary
    # For site 1: χ_left = 1, so doubled dim = 1×1 = 1
    E = transfer_matrix_doubled(ψ.tensors[1])

    # Contract through the chain
    boundary_left = ones(T, 1, size(E, 1))
    result = boundary_left * E

    for k in 2:L
        Ek = transfer_matrix_doubled(ψ.tensors[k])
        result = result * Ek
    end

    # Right boundary: χ_right = 1 for last site, so doubled dim = 1
    boundary_right = ones(T, size(result, 2), 1)
    purity = (result * boundary_right)[1, 1]

    return real(purity)
end

"""
    renyi2_entropy_mps(ψ::MPS) → Float64

Compute the Rényi-2 entropy:  S₂ = −ln(Tr(ρ²))

This is our PRIMARY entropy measure for the MPS-based active inference agent.
It serves as a proxy for Shannon entropy in the epistemic priors.

Properties:
- S₂ ≥ 0 (with equality iff ρ is pure / delta distribution)
- S₂ ≤ S_Shannon ≤ ln(D) (always a lower bound on Shannon entropy)
- Computable in O(T · d · χ⁴) vs O(d^T) for exact Shannon

For the epistemic prior p̃(xₜ) ∝ exp(−H[q(yₜ|xₜ)]):
- We replace H (Shannon) with S₂ (Rényi-2)
- The qualitative behavior is preserved: low entropy → high prior, high entropy → low prior
"""
function renyi2_entropy_mps(ψ::MPS)
    γ = purity_mps(ψ)

    # Clamp for numerical stability
    γ = clamp(γ, 1e-30, 1.0)

    return -log(γ)
end

# ══════════════════════════════════════════════════════════════════════════════
# OPERATION B.2: Von Neumann Entropy at a Bond (Bipartite Entanglement)
# ══════════════════════════════════════════════════════════════════════════════

"""
    vonneumann_entropy_bond(ψ::MPS, bond::Int) → Float64

Compute the von Neumann entanglement entropy at bond `bond`,
i.e., the entropy of the reduced density matrix obtained by
tracing out all sites to the right of `bond`.

S_vN = −∑_i λᵢ² ln(λᵢ²)

where λᵢ are the singular values of the MPS at that bond.

This is useful as a diagnostic: it tells us how much entanglement
exists between the "past" (sites 1..bond) and "future" (sites bond+1..T)
portions of the trajectory.

High entanglement → the agent's belief about past and future states
are strongly correlated → need higher bond dimension χ.
"""
function vonneumann_entropy_bond(ψ::MPS{T}, bond::Int) where T
    L = nsites(ψ)
    @assert 1 ≤ bond < L "Bond index must be between 1 and L-1"

    # Build the matrix Ψ_{(left_indices),(right_indices)} by contracting
    # sites 1..bond into the left block and sites bond+1..L into the right block.

    # Left block: contract sites 1 through bond
    # Start with site 1: shape (1, d₁, χ₁)
    # Reshape to (d₁, χ₁) then iteratively contract
    A1 = ψ.tensors[1].data  # (1, d₁, χ₁)
    d1 = size(A1, 2)
    χ1 = size(A1, 3)
    left_block = reshape(A1, d1, χ1)  # (d₁, χ₁)

    for k in 2:bond
        Ak = ψ.tensors[k].data  # (χ_{k-1}, dₖ, χₖ)
        χk_left = size(Ak, 1)
        dk = size(Ak, 2)
        χk_right = size(Ak, 3)

        # left_block: (D_left, χ_{k-1})
        # Ak reshaped: (χ_{k-1}, dk * χk_right)
        Ak_mat = reshape(Ak, χk_left, dk * χk_right)
        left_block = left_block * Ak_mat  # (D_left, dk * χk_right)
        D_left = div(size(left_block, 1) * dk, dk)  # keeps accumulating
        left_block = reshape(left_block, :, χk_right)
    end

    # Now left_block has shape (D_left_total, χ_bond)
    # SVD to get singular values
    F = svd(left_block)
    λ = F.S

    # Normalize (the squared singular values should sum to 1 for normalized MPS)
    λ² = λ .^ 2
    total = sum(λ²)
    if total > 0
        λ² ./= total
    end

    # Von Neumann entropy
    S = zero(eltype(λ²))
    for p in λ²
        if p > 1e-30
            S -= p * log(p)
        end
    end

    return S
end

# ══════════════════════════════════════════════════════════════════════════════
# OPERATION B.3: Local Entropy (per-site marginal entropy)
# ══════════════════════════════════════════════════════════════════════════════

"""
    local_marginal(ψ::MPS, site::Int) → Vector{Float64}

Compute the marginal probability distribution q(xₜ) at a specific site t
by contracting over all other sites.

This is done via left and right environment contractions:
    q(xₜ) = L[t-1]ᵀ · (A^{xₜ})ᵀ · (A^{xₜ}) · R[t+1]

where L, R are the left and right environment vectors.
"""
function local_marginal(ψ::MPS{T}, site::Int) where T
    L = nsites(ψ)
    d = phys_dim(ψ.tensors[site])

    # Build left environment: contract sites 1..site-1
    # left_env: vector in the doubled bond space, shape (χ², )
    # Actually for diagonal density matrix: left_env_{αα'} = δ_{αα'} contracted
    # through the transfer matrices

    # For the marginal q(x_t) = ψ(x_t)² summed over all other x's:
    # We need ∑_{x₁...x_{t-1}, x_{t+1}...x_T} |A^{x₁}·...·A^{x_T}|²

    # Left environment (vector in bond space)
    if site == 1
        χL = 1
        left_env = ones(T, χL, χL)  # (1,1)
    else
        A1 = ψ.tensors[1].data  # (1, d₁, χ₁)
        # E_left = ∑_{x₁} A^{x₁}ᵀ A^{x₁}  (Gram matrix, shape χ₁×χ₁)
        χ1 = size(A1, 3)
        left_env = zeros(T, χ1, χ1)
        for x in 1:size(A1, 2)
            Ax = A1[1, x, :]  # vector of length χ₁
            left_env .+= Ax * Ax'
        end

        for k in 2:site-1
            Ak = ψ.tensors[k].data
            χk = bond_dim_right(ψ.tensors[k])
            new_env = zeros(T, χk, χk)
            for x in 1:phys_dim(ψ.tensors[k])
                Ax = @view Ak[:, x, :]  # (χ_{k-1}, χ_k)
                # new_env += Axᵀ · left_env · Ax
                new_env .+= Ax' * left_env * Ax
            end
            left_env = new_env
        end
    end

    # Right environment
    if site == L
        χR = 1
        right_env = ones(T, χR, χR)
    else
        AL = ψ.tensors[L].data  # (χ_{L-1}, d_L, 1)
        χLm1 = size(AL, 1)
        right_env = zeros(T, χLm1, χLm1)
        for x in 1:size(AL, 2)
            Ax = AL[:, x, 1]  # vector of length χ_{L-1}
            right_env .+= Ax * Ax'
        end

        for k in L-1:-1:site+1
            Ak = ψ.tensors[k].data
            χk_left = bond_dim_left(ψ.tensors[k])
            new_env = zeros(T, χk_left, χk_left)
            for x in 1:phys_dim(ψ.tensors[k])
                Ax = @view Ak[:, x, :]  # (χ_{k-1}, χ_k)
                new_env .+= Ax * right_env * Ax'
            end
            right_env = new_env
        end
    end

    # Now compute q(x_site) for each physical state x
    A_site = ψ.tensors[site].data  # (χ_L, d, χ_R)
    probs = zeros(Float64, d)

    for x in 1:d
        Ax = @view A_site[:, x, :]  # (χ_L, χ_R)
        # q(x) = Tr(left_env · Ax · right_env · Axᵀ)
        probs[x] = real(tr(left_env * Ax * right_env * Ax'))
    end

    # Normalize
    total = sum(probs)
    if total > 0
        probs ./= total
    end

    return probs
end

"""
    local_entropy_mps(ψ::MPS, site::Int) → Float64

Shannon entropy of the marginal distribution q(xₜ) at site t.
H[q(xₜ)] = −∑_{xₜ} q(xₜ) log q(xₜ)
"""
function local_entropy_mps(ψ::MPS, site::Int)
    probs = local_marginal(ψ, site)
    S = 0.0
    for p in probs
        if p > 1e-30
            S -= p * log(p)
        end
    end
    return S
end

# ══════════════════════════════════════════════════════════════════════════════
# OPERATION B.4: Epistemic Priors for Active Inference (Eq. 13a, 13b)
# ══════════════════════════════════════════════════════════════════════════════

"""
    epistemic_prior_state(ψ_obs::MPS, site::Int) → Float64

Compute the epistemic state prior p̃(xₜ) from Equation 13b:
    p̃(xₜ) ∝ exp(−H[q(yₜ|xₜ)])

Here ψ_obs is the MPS representing the observation model q(y|x).
We compute the local entropy H[q(yₜ|xₜ)] at the observation site
and return exp(−H).

For the MPS approximation, we use Rényi-2 entropy of the local
observation distribution.
"""
function epistemic_prior_state(ψ_obs::MPS, site::Int)
    H = local_entropy_mps(ψ_obs, site)
    return exp(-H)
end

"""
    epistemic_prior_action(ψ_transition::MPS, site_current::Int, site_prev::Int) → Float64

Compute the epistemic action prior p̃(uₜ) from Equation 13a:
    p̃(uₜ) ∝ exp(H[q(xₜ, xₜ₋₁|uₜ)] − H[q(xₜ₋₁|uₜ)])

This is the mutual information between xₜ and xₜ₋₁ given uₜ,
which quantifies how informative the action is about the state transition.

For the MPS approximation:
- H[q(xₜ, xₜ₋₁|uₜ)] ≈ von Neumann entropy at the bond between sites t-1 and t
  (this captures the joint entropy of the bipartition)
- H[q(xₜ₋₁|uₜ)] ≈ local entropy at site t-1
"""
function epistemic_prior_action(ψ_transition::MPS, site_current::Int, site_prev::Int)
    # Joint entropy via bond entanglement entropy (von Neumann at the bond)
    bond = min(site_current, site_prev)
    H_joint = vonneumann_entropy_bond(ψ_transition, bond)

    # Marginal entropy at previous site
    H_marginal = local_entropy_mps(ψ_transition, site_prev)

    # Mutual information = H_joint - H_marginal (approximate)
    # In the exact case: H(X,Y) = H(X) + H(Y|X), so H(X,Y) - H(X) = H(Y|X)
    # The epistemic prior rewards high mutual information
    return exp(H_joint - H_marginal)
end

# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION: Exact Shannon Entropy (for small systems)
# ══════════════════════════════════════════════════════════════════════════════

"""
    shannon_entropy_exact(ψ::MPS) → Float64

Compute the exact Shannon entropy by explicitly constructing the
full probability vector q(x) from the MPS and computing −∑ q log q.

WARNING: This is O(d^T) and only feasible for small systems (T·log₂(d) ≲ 20).
Use only for validation against the MPS-based Rényi entropy.
"""
function shannon_entropy_exact(ψ::MPS{T}) where T
    L = nsites(ψ)
    dims = [phys_dim(ψ.tensors[k]) for k in 1:L]
    total_dim = prod(dims)

    @assert total_dim ≤ 2^20 "State space too large for exact computation ($(total_dim) states)"

    # Enumerate all configurations
    probs = zeros(Float64, total_dim)

    for idx in 0:total_dim-1
        # Decode multi-index
        config = zeros(Int, L)
        remainder = idx
        for k in L:-1:1
            config[k] = (remainder % dims[k]) + 1
            remainder = div(remainder, dims[k])
        end

        # Compute ψ(config) by contracting the MPS
        val = ones(T, 1, 1)  # start with scalar
        for k in 1:L
            # A^{x_k}[k] has shape (χ_left, χ_right)
            Ak = ψ.tensors[k].data[:, config[k], :]  # (χ_left, χ_right)
            if k == 1
                val = reshape(Ak, 1, :)  # (1, χ₁)
            else
                val = val * Ak  # (1, χ_k)
            end
        end

        # val should be (1, 1) scalar
        amplitude = val[1, 1]
        probs[idx + 1] = amplitude^2  # q(x) = ψ(x)²
    end

    # Normalize
    total = sum(probs)
    if total > 0
        probs ./= total
    end

    # Shannon entropy
    S = 0.0
    for p in probs
        if p > 1e-30
            S -= p * log(p)
        end
    end

    return S
end

end # module MPSEntropy
