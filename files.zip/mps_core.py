"""
mps_core.py — Matrix Product State primitives for Active Inference

Pure NumPy implementation of MPS/MPO operations. No external tensor network
library required (quimb/tensornetwork are optional accelerators).

This module provides the data structures and algorithms that replace dense
belief vectors in active inference with compressed tensor-train representations.

Mapping to pymdp concepts:
    pymdp  qs[f]       (1-D array, shape (n_states[f],))   →  MPS site tensor
    pymdp  B[f][:,:,u] (2-D transition matrix per action)  →  MPO site tensor  
    pymdp  A[m]        (observation likelihood)             →  local potential
    pymdp  C[m]        (preference / log-prior on obs)      →  preference potential
"""

import numpy as np
from numpy.linalg import svd, qr, norm
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass, field


# ═══════════════════════════════════════════════════════════════════════════════
# Data Structures
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class MPS:
    """Matrix Product State representing a belief distribution.
    
    Each tensor has shape (chi_left, d, chi_right) where:
        - chi_left/right: bond dimensions (entanglement capacity)
        - d: physical dimension (number of states at this factor/timestep)
    
    The probability distribution is q(x1,...,xN) = |psi(x1,...,xN)|^2
    where psi = contraction of all tensors.
    
    In the pymdp context:
        - For single-factor beliefs: N=1, the MPS is just a normalized vector
        - For multi-factor beliefs: N = num_factors, each site = one factor  
        - For temporal beliefs: N = T (planning horizon), each site = one timestep
    """
    tensors: List[np.ndarray]  # list of 3-D arrays (chi_L, d, chi_R)
    bond_dim: int = 16         # maximum bond dimension chi
    
    @property
    def nsites(self) -> int:
        return len(self.tensors)
    
    @property 
    def phys_dims(self) -> List[int]:
        return [t.shape[1] for t in self.tensors]
    
    def copy(self) -> 'MPS':
        return MPS([t.copy() for t in self.tensors], self.bond_dim)


@dataclass  
class MPO:
    """Matrix Product Operator — represents a linear map on MPS space.
    
    Each tensor has shape (chi_L, d_out, d_in, chi_R).
    Used to represent transition matrices B[f][:,:,u] as tensor networks.
    """
    tensors: List[np.ndarray]  # list of 4-D arrays (chi_L, d_out, d_in, chi_R)
    bond_dim: int = 1


# ═══════════════════════════════════════════════════════════════════════════════
# Construction
# ═══════════════════════════════════════════════════════════════════════════════

def mps_from_dense(vec: np.ndarray, dims: List[int], bond_dim: int = 16) -> MPS:
    """Convert a dense probability vector into an MPS via successive SVDs.
    
    This is the key bridge from pymdp's qs arrays to MPS representation.
    
    Args:
        vec: probability vector of length prod(dims), representing q(x1,...,xN)
        dims: list of physical dimensions [d1, d2, ..., dN]  
        bond_dim: maximum bond dimension for truncation
        
    Returns:
        MPS with N sites, approximating the input distribution
        
    Example (pymdp bridge):
        # pymdp stores qs as object array of marginals: qs[f] shape (n_states[f],)
        # For joint beliefs, flatten the outer product:
        joint = np.einsum('i,j,k->ijk', qs[0], qs[1], qs[2]).flatten()
        mps = mps_from_dense(np.sqrt(joint), [n_states[0], n_states[1], n_states[2]])
    """
    # Work with amplitudes (sqrt of probabilities)
    amplitudes = np.sqrt(np.maximum(vec, 0.0))
    amplitudes /= max(norm(amplitudes), 1e-30)
    
    N = len(dims)
    assert np.prod(dims) == len(amplitudes), \
        f"Product of dims {dims} = {np.prod(dims)} != vector length {len(amplitudes)}"
    
    tensors = []
    residual = amplitudes.reshape(dims)  # N-dimensional tensor
    
    for k in range(N - 1):
        # Current shape: (remaining_left_dim, dims[k], ..., dims[N-1])
        shape = residual.shape
        left_dim = shape[0] if k > 0 else 1
        
        # Reshape to matrix: (left_dim * dims[k], remaining_right)
        mat = residual.reshape(shape[0] * dims[k] if k == 0 else shape[0] * shape[1], -1) \
              if k == 0 else residual.reshape(shape[0] * shape[1], -1)
        
        if k == 0:
            mat = residual.reshape(dims[0], -1)
            U, S, Vt = svd(mat, full_matrices=False)
        else:
            mat = residual.reshape(residual.shape[0] * residual.shape[1], -1)
            U, S, Vt = svd(mat, full_matrices=False)
        
        # Truncate
        chi = min(bond_dim, len(S))
        U = U[:, :chi]
        S = S[:chi]
        Vt = Vt[:chi, :]
        
        # Form tensor for site k
        if k == 0:
            tensor = U.reshape(1, dims[k], chi)
        else:
            tensor = U.reshape(residual.shape[0], residual.shape[1], chi)
            # Need to merge the first two axes properly
            tensor = U.reshape(-1, dims[k], chi)  # WRONG if residual has 3+ dims
            # Actually, let's be more careful:
            chi_left = residual.shape[0]
            tensor = U.reshape(chi_left, dims[k], chi)
        
        tensors.append(tensor)
        
        # Residual for next iteration: absorb S into Vt
        residual_mat = np.diag(S) @ Vt
        remaining_dims = [chi] + list(dims[k+1:])
        residual = residual_mat.reshape(remaining_dims)
    
    # Last tensor
    tensors.append(residual.reshape(residual.shape[0], dims[-1], 1))
    
    return MPS(tensors, bond_dim)


def mps_product_state(dims: List[int], probs: Optional[List[np.ndarray]] = None,
                      bond_dim: int = 16) -> MPS:
    """Create a product-state MPS (zero entanglement between sites).
    
    This is the direct replacement for pymdp's factorized posterior:
        qs = obj_array(num_factors)
        qs[f] = uniform(n_states[f])  
    becomes:
        mps = mps_product_state([n_states[f] for f in range(num_factors)])
    
    Args:
        dims: physical dimensions [d1, d2, ..., dN]
        probs: optional list of probability vectors, one per site.
               If None, uniform distributions are used.
        bond_dim: maximum bond dimension (irrelevant for product states, but stored)
    """
    tensors = []
    for k, d in enumerate(dims):
        if probs is not None and probs[k] is not None:
            p = np.asarray(probs[k], dtype=np.float64)
            p = p / max(p.sum(), 1e-30)
        else:
            p = np.ones(d) / d
        
        # Amplitude = sqrt(probability)
        amp = np.sqrt(np.maximum(p, 0.0))
        amp /= max(norm(amp), 1e-30)
        
        # Shape: (1, d, 1) — bond dimension 1 for product state
        tensors.append(amp.reshape(1, d, 1))
    
    return MPS(tensors, bond_dim)


def mps_to_dense(mps: MPS) -> np.ndarray:
    """Contract an MPS back into a dense probability vector.
    
    WARNING: O(prod(dims)) — only for validation on small systems.
    
    Returns:
        1-D array of probabilities q(x1,...,xN), length = prod(phys_dims)
    """
    # Contract left to right
    result = mps.tensors[0]  # (1, d0, chi1)
    for k in range(1, mps.nsites):
        # result shape: (1, D_accumulated, chi_k)
        # next tensor: (chi_k, d_k, chi_{k+1})
        # Contract over chi_k
        result = np.einsum('...i,ijk->...jk', result, mps.tensors[k])
    
    # result shape: (1, d0, d1, ..., dN, 1) — squeeze boundary dims
    amplitudes = result.squeeze()
    probs = amplitudes ** 2
    probs = probs.flatten()
    total = probs.sum()
    if total > 0:
        probs /= total
    return probs


# ═══════════════════════════════════════════════════════════════════════════════
# Normalization & Canonical Forms
# ═══════════════════════════════════════════════════════════════════════════════

def left_canonicalize(mps: MPS) -> MPS:
    """Put MPS in left-canonical form via QR sweep, then normalize."""
    tensors = [t.copy() for t in mps.tensors]
    N = len(tensors)
    
    for k in range(N - 1):
        chi_L, d, chi_R = tensors[k].shape
        mat = tensors[k].reshape(chi_L * d, chi_R)
        Q, R = qr(mat)
        new_chi = Q.shape[1]
        tensors[k] = Q.reshape(chi_L, d, new_chi)
        
        # Absorb R into next tensor
        chi_L2, d2, chi_R2 = tensors[k + 1].shape
        next_mat = tensors[k + 1].reshape(chi_L2, d2 * chi_R2)
        tensors[k + 1] = (R @ next_mat).reshape(new_chi, d2, chi_R2)
    
    # Normalize last tensor
    n = norm(tensors[-1].flatten())
    if n > 0:
        tensors[-1] /= n
    
    return MPS(tensors, mps.bond_dim)


def svd_truncate(mps: MPS, chi_max: Optional[int] = None) -> MPS:
    """Truncate MPS bond dimensions via SVD sweep."""
    if chi_max is None:
        chi_max = mps.bond_dim
    
    tensors = [t.copy() for t in mps.tensors]
    N = len(tensors)
    
    for k in range(N - 1):
        chi_L, d, chi_R = tensors[k].shape
        mat = tensors[k].reshape(chi_L * d, chi_R)
        U, S, Vt = svd(mat, full_matrices=False)
        
        chi_new = min(chi_max, len(S))
        U = U[:, :chi_new]
        S = S[:chi_new]
        Vt = Vt[:chi_new, :]
        
        tensors[k] = U.reshape(chi_L, d, chi_new)
        SV = np.diag(S) @ Vt
        
        chi_L2, d2, chi_R2 = tensors[k + 1].shape
        next_mat = tensors[k + 1].reshape(chi_L2, d2 * chi_R2)
        tensors[k + 1] = (SV @ next_mat).reshape(chi_new, d2, chi_R2)
    
    # Normalize
    n = norm(tensors[-1].flatten())
    if n > 0:
        tensors[-1] /= n
    
    return MPS(tensors, chi_max)


# ═══════════════════════════════════════════════════════════════════════════════
# Local Marginals (bridges back to pymdp's qs[f] format)
# ═══════════════════════════════════════════════════════════════════════════════

def local_marginal(mps: MPS, site: int) -> np.ndarray:
    """Compute the marginal q(x_site) by tracing over all other sites.
    
    This is the inverse of the pymdp bridge: it extracts a marginal from
    the MPS to produce the same object as pymdp's qs[f].
    
    Returns: 1-D probability array of shape (d_site,)
    """
    N = mps.nsites
    d = mps.tensors[site].shape[1]
    
    # Build left environment: Gram matrices contracted from site 0 to site-1
    if site == 0:
        left_env = np.array([[1.0]])
    else:
        A = mps.tensors[0]  # (1, d0, chi1)
        chi1 = A.shape[2]
        left_env = np.zeros((chi1, chi1))
        for x in range(A.shape[1]):
            ax = A[0, x, :]  # (chi1,)
            left_env += np.outer(ax, ax)
        
        for k in range(1, site):
            Ak = mps.tensors[k]  # (chi_k, d_k, chi_{k+1})
            chi_next = Ak.shape[2]
            new_env = np.zeros((chi_next, chi_next))
            for x in range(Ak.shape[1]):
                ax = Ak[:, x, :]  # (chi_k, chi_{k+1})
                new_env += ax.T @ left_env @ ax
            left_env = new_env
    
    # Build right environment
    if site == N - 1:
        right_env = np.array([[1.0]])
    else:
        AL = mps.tensors[-1]  # (chi_{N-1}, d_N, 1)
        chi_last = AL.shape[0]
        right_env = np.zeros((chi_last, chi_last))
        for x in range(AL.shape[1]):
            ax = AL[:, x, 0]  # (chi_{N-1},)
            right_env += np.outer(ax, ax)
        
        for k in range(N - 2, site, -1):
            Ak = mps.tensors[k]
            chi_left = Ak.shape[0]
            new_env = np.zeros((chi_left, chi_left))
            for x in range(Ak.shape[1]):
                ax = Ak[:, x, :]
                new_env += ax @ right_env @ ax.T
            right_env = new_env
    
    # Compute q(x_site) for each state
    A_site = mps.tensors[site]
    probs = np.zeros(d)
    for x in range(d):
        ax = A_site[:, x, :]  # (chi_L, chi_R)
        probs[x] = np.trace(left_env @ ax @ right_env @ ax.T)
    
    probs = np.maximum(probs, 0.0)
    total = probs.sum()
    if total > 0:
        probs /= total
    return probs


def all_marginals(mps: MPS) -> List[np.ndarray]:
    """Extract marginals at all sites — directly maps to pymdp's qs object array.
    
    Returns: list of 1-D arrays, one per site, matching pymdp's qs format.
    """
    return [local_marginal(mps, k) for k in range(mps.nsites)]


# ═══════════════════════════════════════════════════════════════════════════════
# MPO Operations (Operation A: Transition)
# ═══════════════════════════════════════════════════════════════════════════════

def transition_matrix_to_mpo(B_matrix: np.ndarray) -> MPO:
    """Convert a dense transition matrix B[:,:,u] into a single-site MPO.
    
    pymdp's B[f][:,:,u] has shape (n_states[f], n_states[f]) representing
    p(s'|s, u) for factor f under action u.
    
    Returns: MPO with one tensor of shape (1, d_out, d_in, 1)
    """
    d = B_matrix.shape[0]
    W = B_matrix.reshape(1, d, d, 1)
    return MPO([W], bond_dim=1)


def apply_mpo_to_site(mps: MPS, mpo: MPO, site: int) -> MPS:
    """Apply a single-site MPO (transition) to one site of the MPS.
    
    This replaces: qs[f] = B[f][:,:,u] @ qs[f]  
    with the MPS-native version that preserves tensor structure.
    
    The result's bond dimension may grow; use svd_truncate afterwards.
    """
    tensors = [t.copy() for t in mps.tensors]
    
    A = tensors[site]        # (chi_L, d_in, chi_R)
    W = mpo.tensors[0]       # (1, d_out, d_in, 1) for single-site MPO
    
    chi_L, d_in, chi_R = A.shape
    _, d_out, _, _ = W.shape
    
    # Contract: B^{x_out}_{alpha,beta} = sum_{x_in} W[0,x_out,x_in,0] * A[alpha,x_in,beta]
    # New shape: (chi_L * 1, d_out, chi_R * 1) = (chi_L, d_out, chi_R)
    new_tensor = np.einsum('aib,jki->ajb', A, W[0, :, :, 0])
    # W[0,:,:,0] has shape (d_out, d_in), A has shape (chi_L, d_in, chi_R)
    # einsum 'aib,ji->ajb' means new[a,j,b] = sum_i A[a,i,b] * W[j,i]
    new_tensor = np.einsum('aib,ji->ajb', A, W[0, :, :, 0])
    
    tensors[site] = new_tensor
    result = MPS(tensors, mps.bond_dim)
    return svd_truncate(left_canonicalize(result))


# ═══════════════════════════════════════════════════════════════════════════════
# Entropy Operations (Operation B)
# ═══════════════════════════════════════════════════════════════════════════════

def transfer_matrix_doubled(A: np.ndarray) -> np.ndarray:
    """Compute doubled transfer matrix for purity calculation.
    
    A has shape (chi_L, d, chi_R).
    Returns E of shape (chi_L^2, chi_R^2) where
    E_{(a1,a2),(b1,b2)} = sum_x A[a1,x,b1] * A[a2,x,b2]
    """
    chi_L, d, chi_R = A.shape
    E = np.zeros((chi_L * chi_L, chi_R * chi_R))
    
    for x in range(d):
        Ax = A[:, x, :]  # (chi_L, chi_R)
        # Kronecker product of Ax with itself
        E += np.kron(Ax, Ax)
    
    return E


def purity(mps: MPS) -> float:
    """Compute Tr(rho^2) = sum_x q(x)^2 via transfer matrix contraction.
    
    Complexity: O(N * d * chi^4) — polynomial in system size.
    """
    E = transfer_matrix_doubled(mps.tensors[0])
    
    for k in range(1, mps.nsites):
        Ek = transfer_matrix_doubled(mps.tensors[k])
        E = E @ Ek
    
    return float(np.real(E.item() if E.size == 1 else np.trace(E)))


def renyi2_entropy(mps: MPS) -> float:
    """Rényi-2 entropy: S2 = -ln(Tr(rho^2)). Proxy for Shannon entropy."""
    gamma = np.clip(purity(mps), 1e-30, 1.0)
    return -np.log(gamma)


def shannon_entropy_site(mps: MPS, site: int) -> float:
    """Shannon entropy of the marginal at one site: H[q(x_k)]."""
    p = local_marginal(mps, site)
    return -np.sum(p * np.log(np.maximum(p, 1e-30)))


def observation_entropy(A_matrix: np.ndarray, state_probs: np.ndarray) -> float:
    """H[q(y|x)] averaged over q(x) — the epistemic state prior term.
    
    A_matrix: shape (n_obs, n_states), the observation likelihood
    state_probs: shape (n_states,), the current belief q(x)
    
    Returns: E_q(x)[H[p(y|x)]]
    """
    n_obs, n_states = A_matrix.shape
    H = 0.0
    for s in range(n_states):
        p_y = A_matrix[:, s]
        p_y = p_y / max(p_y.sum(), 1e-30)
        h = -np.sum(p_y * np.log(np.maximum(p_y, 1e-30)))
        H += state_probs[s] * h
    return H


# ═══════════════════════════════════════════════════════════════════════════════
# Variational Sweep (Operation C: DMRG-like local optimization)
# ═══════════════════════════════════════════════════════════════════════════════

def apply_local_potential(mps: MPS, site: int, potential: np.ndarray) -> MPS:
    """Apply a diagonal potential (multiplicative weight) at one site.
    
    This is how we incorporate:
    - Observation likelihood:  potential = A[o, :]  (column of A for observation o)
    - Preference prior:        potential = softmax(C)
    - Epistemic state prior:   potential = exp(-H[p(y|x)])
    
    Replaces pymdp's: qs[f] = softmax(log(A[o,:]) + log(prior))
    """
    tensors = [t.copy() for t in mps.tensors]
    A = tensors[site]  # (chi_L, d, chi_R)
    d = A.shape[1]
    
    assert len(potential) == d, f"Potential length {len(potential)} != d={d}"
    
    # Apply sqrt(potential) to amplitudes (since q = psi^2)
    sqrt_pot = np.sqrt(np.maximum(potential, 1e-30))
    for x in range(d):
        A[:, x, :] *= sqrt_pot[x]
    
    tensors[site] = A
    result = MPS(tensors, mps.bond_dim)
    return svd_truncate(left_canonicalize(result))


def variational_sweep(mps: MPS, potentials: List[np.ndarray],
                      n_sweeps: int = 2) -> MPS:
    """Perform DMRG-like variational sweep applying local potentials.
    
    This replaces pymdp's iterative state inference:
        for _ in range(num_iter):
            qs = softmax(log_likelihood + log_prior)
    
    with tensor network variational optimization.
    
    Args:
        mps: current belief MPS
        potentials: list of 1-D arrays, one per site (local weights)
        n_sweeps: number of left-right-left sweeps
    """
    result = mps.copy()
    
    for sweep in range(n_sweeps):
        # Left to right
        for k in range(result.nsites):
            if potentials[k] is not None:
                result = apply_local_potential(result, k, potentials[k])
        
        # Right to left (same potentials, but sweep order matters for canonicalization)
        for k in range(result.nsites - 1, -1, -1):
            if potentials[k] is not None:
                result = apply_local_potential(result, k, potentials[k])
    
    return result
